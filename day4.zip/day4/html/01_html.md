# HTML

## 1. HTML 이란?

- HTML은 Hyper Text Markup Language의 약자로 웹 문서를 작성하는 마크업 언어 입니다.



## 2. HTML 구성 요소

- HTML 마크업 언어는 Element의 조합으로 구성이 되어 있습니다.

- Element는 Tag와 Attribute로 구성이 되어 있습니다.

- Element는 시작 태그와 끝 태그가 있습니다.

- Attribute는 id와 class와 attribute가 있습니다.

- id와 class는 주로 element를 구분 하는 용도로 사용됩니다.

    ```html
    <!-- 사용 예 -->
    <div class="wrapper">
        <button class="btn no1" type="button" value="1">HTML 1</button>
        <button class="btn no2" type="button" value="2">HTML 2</button>
    </div>
    ```

- attribute : 속성값
    - id
        - 웹 페이지에서 유일한 값
    - class
        - 동일한 여러개의 값을 사용하는게 가능
        - element를 그룹핑 할때 사용
    - attr
        - id와 class를 제외한 나머지 속성들



## 3. HTML 구조

- DOCTYPE

    - 문서의 종류를 선언하는 태그 입니다.
- html
    - head
        - meta
            - 웹페이지에 대한 정보를 넣습니다.
        - title
            - 웹페이지의 제목 정보를 넣습니다.
    - body
        - 화면을 구성하는 엘리먼트가 옵니다.
    ```html
    <!-- HTML 웹문서의 기본적인 구조 -->
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
    
    </body>
    </html>
    ```



## 4. HTML 문자 태그

- html에서 문자를 나타내는 태그들



### 4.1 head

- title을 나타낼때 사용
- Head는 총 6가지 종류의 태그가 있습니다.(h1~h6)
- 숫자가 커질수록 문자의 크기가 줄어듭니다.
    ```html
    <h1>Heading</h1>
    <h2>Heading</h2>
    <h3>Heading</h3>
    <h4>Heading</h4>
    <h5>Heading</h5>
    <h6>Heading</h6>
    ```



### 4.2 p

- 한줄의 문자열을 출력하기 위한 태그
    ```html
    <p>HTML은 마크업 언어 입니다.</p>
    <p>p 태그는 한줄로 문자열을 출력합니다.</p>
    ```



### 4.3 span

- 한블럭의 문자열을 표현하기 위한 태그
    ```html
    <span class="s1">span-tag-0</span>
    <span class="s2">span-tag-1</span>
    <span class="s3">span-tag-2</span>
    ```



### 4.4 br

- 줄바꿈을 할때 사용되는 태그
    ```html
    <span class="s1">span-tag-0</span><br>
    <span class="s2">span-tag-1</span><br>
    <span class="s3">span-tag-2</span><br>
    ```

    

### 4.5 pre

- 줄바꿈이나 띄어쓰기가 적용되는 태그
    ```html
    <p>
        python
        datascience
    </p>
    <pre>
        python
        datascience
    </pre>
    ```



### 4.6 code

- 코드를 작성하는 태그
- 들여쓰기나 두칸 이상의 공백은 적용이 안됩니다.
    ```html
    <code>
        var a = 10;
        var b = 20;
        print("{} + {} =  {}".format(a, b, a + b));
    </code>
    ```
- 들여쓰기나 여러칸의 공백사용을 위해서 `&nbsp;` 나 `br` 태그를 사용
    ```html
    <code>
        var a = 10;<br>
        var b = 20;<br>
        print("{} + {} =&nbsp;&nbsp;{}".format(a, b, a + b));
    </code>
    ```



### 4.6 글씨체



#### 4.6.1 b, strong

- 강조, 굵은글씨를 나타내는 태그
    ```html
    <p><b>강조, 굵은글씨</b></p>
    <p><strong>강조, 굵은글씨</strong></p>
    ```



#### 4.6.2 i, em

- 이탤릭체를 나타내는 태그
    ```html
    <p><i>이탤릭체</i></p>
    <p><strong><em>이탤릭체</em></strong></p>
    ```



#### 4.6.3 sub, sup

- 아래첨자, 윗첨자를 나타내는 태그
    ```html
    <p>아래첨자<sub>아래첨자</sub></p>
    <p>윗첨자<sup>윗첨자</sup></p>
    ```



#### 4.6.4 small, mark

- 작은글씨, 글자배경(노란색)을 나타내는 태그
    ```html
    <p>작은글씨<small>작은글씨</small></p>
    <p>글자 배경이 <mark>노란색</mark> 입니다.</p>
    ```



#### 4.6.4 del, ins

- 삭제문자열, 언더라인 문자열을 나타내는 태그
    ```html
    <p>삭제문자열<del>삭제문자열</del></p>
    <p>언더라인 문자열 <ins>언더라인 문자열</ins> 입니다.</p>
    ```



## 5. 문자 이외의 HTML 태그



### 5.1 div

- 레이아웃을 나타내는 태그
    ```html
    <div>
        <p>div1</p>
        <p>div1</p>
        <p>div1</p>
    </div>
    <div>div2</div>
    <div>div3</div>
    ```



### 5.2 table

- 로우와 컬럼이 있는 테이블 모양을 나타낼때 사용하는 태그
    ```html
    <table>
        <caption>테이블</caption>
        <thead>
            <tr>
                <th>html_1</th>
                <th>html_2</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th>html_3</th>
                <th>html_4</th>
            </tr>
        </tbody>
    </table>
    ```



### 5.3 ul, li

- 리스트를 나타내는 태그
    ```html
    <ul>
        <li>ul_li_1</li>
        <li>ul_li_2</li>
        <li>ul_li_3</li>
    </ul>
    ```
- `list-style: none;`으로 스타일을 설정하면 `li` 엘리먼트 앞의 점을 제거할수 있습니다.



### 5.4 a

- 링크를 나타내는 태그
- href 속성에 url을 넣습니다.
    - url과 상대경로를 모두 사용 가능
    ```html
    <a href="http://google.com" target="_blank">Google</a>
    <a href="01_html_1.md">html basic</a>
    ```
- `target="_blank"`는 링크를 열때 새탭에서 열도록 하는 기능이 있습니다.



### 5.5 image

- 이미지를 나타내는 태그
    ```html
    <img style="width:200px;" src="http://cdn.www.fastcampus.co.kr/wp-content/uploads/2017/11/fastcampus_logo_positive-1.png" alt="패스트캠퍼스">
    ```



### 5.4 iframe

- 외부 url 링크 페이지를 보여주기 위한 엘리먼트
    ```html
    <iframe src="https://www.zigbang.com" width="100%" height="800"></iframe>
    ```
- 모든 웹 페이지를 보여줄수있는건 아니고 iframe으로만 출력이 되던가 안되거나 하는등의 설정을 할수 있습니다.



### 5.5 input



#### 5.5.1 text

- 문자열을 입력받을때 사용하는 input 타입
    ```html
    <input type="text" name="" value="" placeholder="이메일">
    ```



#### 5.5.2 password

- 비밀번호를 입력받을때 사용하는 input 타입
    ```html
    <input type="password" name="" value="" placeholder="패스워드">
    ```

    

#### 5.5.3 radio

- 여러개의 버튼중에서 한개의 버튼만 체크되는 버튼
- radio 버튼은 name 속성값으로 그룹핑을 합니다.
    ```html
    <input type="radio" name="radio1" value="1">라디오1</input>
    <input type="radio" name="radio1" value="2">라디오1</input><br>
    <input type="radio" name="radio2" value="3">라디오2</input>
    <input type="radio" name="radio2" value="4">라디오2</input>
    <input type="radio" name="radio2" value="5">라디오2</input><br>
    ```



#### 5.5.4 checkbox

- 여러개의 버튼이 체크되는 버튼
    ```html
    <input type="checkbox" name="checkbox1" value="1">체크박스1</input>
    <input type="checkbox" name="checkbox1" value="2">체크박스2</input>
    ```



#### 5.5.5 select, option

- 옵션선택을 할수 있는 드랍다운 태그
    ```html
    <select>
        <option value="1">option 1</option>
        <option value="2">option 2</option>
        <option value="3">option 3</option>
    </select>
    ```



### 5.6 textarea

- 여러줄을 입력이 가능한 태그
    ```html
    <textarea name="name" rows="8" cols="30" ></textarea>
    ```



### 5.7 button

- 마우스 클릭을 입력받는 버튼 태그
    ```html
    <button type="button">Click</button>
    ```
